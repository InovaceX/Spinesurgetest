import React, { useEffect, useState } from "react";
import logo from "./logo.png.svg"; // Make sure this exists in your src folder

const navItems = [
  { label: "Measure", icon: (<svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24"><path d="M21 16v4a2 2 0 0 1-2 2h-4" /><polyline points="21 16 12 3 3 16" /><polyline points="3 16 9 16 9 22" /></svg>) },
  { label: "Spine", icon: (<svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3" /><path d="M12 2v2M12 20v2M18 12h2M4 12H2M16.95 7.05l1.4-1.4M5.64 18.36l1.4-1.4M16.95 16.95l1.4 1.4M5.64 5.64l1.4 1.4" /></svg>) },
  { label: "Geometric", icon: (<svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24"><polygon points="12 2 19 21 5 21 12 2" /></svg>) },
  { label: "Surgical", icon: (<svg width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" viewBox="0 0 24 24"><path d="M12 14l9-5-9-5-9 5 9 5z" /><path d="M12 14v7" /><path d="M12 14L3 9" /><path d="M21 9l-9 5" /></svg>) }
];

const quickAccessItems = [
  { icon: "📏", label: "Measure" },
  { icon: "🔍+", label: "Zoom In" },
  { icon: "🔍−", label: "Zoom Out" },
  { icon: "🤚", label: "Pan" }
];

const toolCategories = [
  {
    title: "Measure Tools",
    items: [
      "Distance Measurement",
      "Angle Measurement",
      "Curve Analysis",
      "Region Selection"
    ]
  },
  {
    title: "Spine Tools",
    items: [
      "Cobb Angle",
      "Pelvic Parameters",
      "Vertebral Height",
      "Scoliosis Analysis"
    ]
  },
  {
    title: "Geometric Tools",
    items: [
      "Polygon Area",
      "Circle Fitting",
      "Line Intersection"
    ]
  },
  {
    title: "Surgical Tools",
    items: [
      "Implant Planning",
      "Screw Trajectory",
      "Fusion Assessment"
    ]
  }
];

const favorites = ["Cobb Angle", "Distance Measurement"];

const analysisResults = {
  spinalParameters: [
    { label: "Pelvic Incidence", value: "45°", normal: "Normal: 45-75°" },
    { label: "Pelvic Tilt", value: "12°", normal: "Normal: 10-25°" },
    { label: "Sacral Slope", value: "33°", normal: "Normal: 30-50°" },
    { label: "Lumbar Lordosis", value: "42°", normal: "Normal: 40-60°" }
  ],
  measurements: [
    { label: "Cobb Angle T1-T12", sub: "Angle", value: "15°" },
    { label: "Distance L1-L5", sub: "Distance", value: "12.5 cm" },
    { label: "Vertebral Height L3", sub: "Distance", value: "2.8 cm" }
  ],
  summary: {
    totalMeasurements: 3,
    parametersCalculated: 4,
    status: "Normal Range"
  }
};

export default function SpineSurge() {
  const [darkMode, setDarkMode] = useState(true);
  const [showQuickAccess, setShowQuickAccess] = useState(true);
  const [showToolCats, setShowToolCats] = useState(true);
  const [showFavorites, setShowFavorites] = useState(true);
  const [showSpinalParams, setShowSpinalParams] = useState(true);
  const [showMeasurements, setShowMeasurements] = useState(true);
  const [showSummary, setShowSummary] = useState(true);
  const [maxBrightness, setMaxBrightness] = useState(false);

  useEffect(() => {
    document.body.setAttribute("data-theme", darkMode ? "dark" : "light");
  }, [darkMode]);

  // THEME CSS
  const globalStyles = `
    html, body, #root,
    .container,
    aside.sidebar,
    aside.right-panel,
    main.main-workspace,
    .sidebar-section,
    section.panel-section,
    .upload-area,
    .image-editing-bottom-bar,
    .workspace-header,
    .sidebar-section .section-header,
    .sidebar-section .section-content,
    .favorites button,
    .param-item,
    .param-value,
    .param-normal,
    .measurement-item,
    .measurement-value,
    .summary-item,
    .summary-status,
    button,
    .zoom-controls,
    .upload-desc,
    .upload-text,
    .topbar-right,
    .icon-btn {
      transition: background-color 0.7s cubic-bezier(.4,0,.2,1), color 0.7s cubic-bezier(.4,0,.2,1);
    }
    [data-theme="dark"] {
      --blue: #2746b0;
      --blue-dark: #1a2540;
      --blue-light: #19244a;
      --blue-lighter: #223471;
      --blue-border: #223471;
      --shadow: 0 1px 6px #1d2a55;
      --text: #f7faff;
      --text-light: #e3eafe;
      --text-heading: #fff;
      --star: #ffe066;
      --param-bg: #a4d18e;
      --param-green: #236400;
      --panel-bg: #223471;
      --sidebar-bg: #1a2340;
      --input-bg: #223471;
      --accent: #3a5cf9;
      --button-bg: #3a5cf9;
      --button-text: #fff;
      --button-hover: #4a65f3;
    }
    [data-theme="light"] {
      --blue: #2746b0;
      --blue-dark: #1a2540;
      --blue-light: #f7faff;
      --blue-lighter: #e3eafc;
      --blue-border: #e2e8f0;
      --shadow: 0 1px 6px #e9ecf6;
      --text: #1a2540;
      --text-light: #2746b0;
      --text-heading: #1a2540;
      --star: #ffb300;
      --param-bg: #e5f4d8;
      --param-green: #236400;
      --panel-bg: #fff;
      --sidebar-bg: #f7faff;
      --input-bg: #fff;
      --accent: #2746b0;
      --button-bg: #2746b0;
      --button-text: #fff;
      --button-hover: #3a5cf9;
    }
    body {
      background: var(--blue-light);
      color: var(--text);
    }
    button, input, select, textarea {
      font-family: inherit;
      font-size: inherit;
      color: inherit;
      background: none;
      border: none;
      outline: none;
    }
    header.topbar {
      display: flex; align-items: center; justify-content: space-between;
      background-color: var(--blue);
      height: 56px;
      padding: 0 20px;
      user-select: none;
      font-weight: 600;
      font-size: 15px;
      color: #fff;
      gap: 1rem;
    }
    header .logo {
      height: 32px;
      cursor: pointer;
      user-select: none;
    }
    nav.nav-center {
      flex: 1;
      display: flex;
      gap: 1.6rem;
      justify-content: center;
      align-items: center;
    }
    nav.nav-center button {
      background-color: transparent;
      border: none;
      color: #fff;
      gap: 8px;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      border-radius: 6px;
      padding: 6px 15px;
      display: flex;
      align-items: center;
      user-select: none;
      transition: background-color 0.3s, color 0.3s;
      line-height: 1;
    }
    nav.nav-center button svg {
      stroke: #fff;
      stroke-width: 2;
      width: 18px;
      height: 18px;
    }
    nav.nav-center button:hover,
    nav.nav-center button.active {
      background-color: #1a2993;
      box-shadow: 0 0 8px #1a2993cc;
    }
    .theme-toggle-btn {
      background: none;
      border: none;
      margin-left: 18px;
      cursor: pointer;
      color: #fff;
      display: flex;
      align-items: center;
      padding: 4px 8px;
      border-radius: 6px;
      font-size: 20px;
      transition: background 0.3s, color 0.3s;
    }
    .theme-toggle-btn:hover {
      background: var(--accent);
      color: #ffe066;
    }
    [data-theme="light"] .theme-toggle-btn {
      color: var(--blue);
    }
    [data-theme="light"] .theme-toggle-btn:hover {
      color: #ffb300;
    }
    .container {
      display: flex;
      height: calc(100vh - 56px);
      overflow: hidden;
      position: relative;
      padding-bottom: 60px;
      background: var(--blue-light);
    }
    aside.sidebar {
      flex-shrink: 0;
      width: 270px;
      background-color: var(--sidebar-bg);
      padding: 16px 20px;
      display: flex;
      flex-direction: column;
      gap: 16px;
      box-sizing: border-box;
      overflow-y: auto;
      color: var(--text);
      user-select: none;
      border-right: 1px solid var(--blue-border);
    }
    .collapse-control {
      cursor: pointer;
      font-weight: 600;
      font-size: 14px;
      margin-bottom: 4px;
      color: var(--blue);
      user-select: none;
    }
    .collapse-control:hover {
      text-decoration: underline;
    }
    .sidebar-section {
      background-color: var(--panel-bg);
      border-radius: 12px;
      padding: 16px 18px;
      box-shadow: var(--shadow);
      margin-bottom: 8px;
    }
    .sidebar-section .section-header {
      font-weight: 700;
      font-size: 14px;
      margin-bottom: 12px;
      color: var(--text-heading);
      cursor: pointer;
      user-select: none;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .sidebar-section.collapsed .section-content {
      display: none;
    }
    .sidebar-section .section-content {
      font-weight: 600;
      font-size: 14px;
      color: var(--text-light);
      user-select: none;
      display: flex;
      flex-direction: column;
      gap: 0;
    }
    .sidebar-section .section-content > div,
    .sidebar-section .section-content > button {
      margin-bottom: 8px;
      cursor: pointer;
      border: none;
      background: transparent;
      color: var(--text-light);
      user-select: none;
      text-align: left;
      padding-left: 16px;
      display: flex;
      gap: 8px;
      align-items: center;
      font-weight: 600;
    }
    .sidebar-section .section-content > div:last-child,
    .sidebar-section .section-content > button:last-child {
      margin-bottom: 0;
    }
    .sidebar-section .section-content div span.icon-dot {
      color: var(--blue);
      font-size: 16px;
      line-height: 1;
    }
    .favorites button {
      color: var(--star);
      font-weight: 700;
      user-select: none;
    }
    .favorites button span.icon-dot {
      color: var(--star);
    }
    main.main-workspace {
      flex-grow: 1;
      /* Always black workspace */
      background-color: #000 !important;
      display: flex;
      flex-direction: column;
      padding: 20px 24px;
      box-sizing: border-box;
      gap: 8px;
      user-select: none;
      position: relative;
    }
    .workspace-header {
      font-weight: 700;
      font-size: 17px;
      color: var(--text-heading);
      display: flex;
      justify-content: space-between;
      align-items: center;
      user-select: none;
    }
    .zoom-controls {
      position: absolute;
      top: 20px;
      right: 24px;
      background-color: var(--panel-bg);
      border-radius: 12px;
      padding: 6px 12px;
      display: flex;
      gap: 12px;
      align-items: center;
      user-select: none;
      box-sizing: border-box;
      box-shadow: 0 0 12px var(--panel-bg);
      z-index: 5;
    }
    button.zoom-btn {
      background: transparent;
      border: none;
      color: var(--text-heading);
      font-weight: 700;
      font-size: 20px;
      cursor: pointer;
      padding: 3px 8px;
      border-radius: 8px;
      transition: background-color 0.25s, color 0.25s;
      user-select: none;
    }
    button.zoom-btn:hover {
      background-color: var(--accent);
      color: #fff;
    }
    .zoom-divider {
      width: 2px;
      background-color: #b3c7f6;
      height: 28px;
      border-radius: 3px;
      user-select: none;
    }
    .upload-area {
      flex-grow: 1;
      background-color: #000 !important;
      border-radius: 14px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 30px 15px;
      text-align: center;
      user-select: none;
      position: relative;
      box-shadow: var(--shadow);
    }
    .upload-area .upload-icon {
      font-size: 48px;
      margin-bottom: 16px;
      user-select: none;
      color: #7bb6ff;
    }
    .upload-area .upload-text {
      font-weight: 700;
      font-size: 18px;
      margin-bottom: 6px;
      color: #fff;
      user-select: none;
    }
    .upload-area .upload-desc {
      font-weight: 400;
      font-size: 13px;
      color: #b5c3e7;
      margin-bottom: 16px;
      user-select: none;
    }
    button.upload-button {
      background-color: var(--button-bg);
      border: none;
      color: var(--button-text);
      font-weight: 700;
      font-size: 14px;
      padding: 12px 24px;
      border-radius: 10px;
      cursor: pointer;
      user-select: none;
      transition: background-color 0.3s, color 0.3s;
    }
    button.upload-button:hover {
      background-color: var(--button-hover);
    }
    aside.right-panel {
      flex-shrink: 0;
      width: 300px;
      background-color: var(--sidebar-bg);
      padding: 20px;
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      gap: 20px;
      overflow-y: auto;
      color: var(--text);
      user-select: none;
      border-left: 1px solid var(--blue-border);
    }
    section.panel-section {
      background-color: var(--panel-bg);
      border-radius: 12px;
      padding: 20px 20px 12px 20px;
      box-sizing: border-box;
      user-select: none;
      box-shadow: var(--shadow);
    }
    section.panel-section h3 {
      font-weight: 700;
      margin: 0 0 12px 0;
      cursor: pointer;
      color: var(--text-heading);
      font-size: 17px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      user-select: none;
    }
    section.panel-section h3:hover {
      color: var(--accent);
    }
    .param-item {
      display: flex;
      justify-content: space-between;
      font-weight: 700;
      font-size: 14px;
      margin-bottom: 2px;
      color: var(--text-light);
      user-select: none;
    }
    .param-normal {
      font-weight: 400;
      font-size: 12px;
      color: #b5c3e7;
      margin-left: 14px;
      margin-bottom: 12px;
      user-select: none;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .param-value {
      background-color: var(--param-bg);
      color: var(--param-green);
      font-weight: 700;
      font-size: 14px;
      padding: 3px 12px;
      border-radius: 14px;
      min-width: 38px;
      text-align: center;
      user-select: none;
    }
    button.param-button {
      margin-top: 10px;
      background-color: var(--button-bg);
      border: none;
      border-radius: 12px;
      color: var(--button-text);
      font-weight: 700;
      font-size: 15px;
      width: 100%;
      padding: 12px 0;
      cursor: pointer;
      user-select: none;
      display: flex;
      justify-content: center;
      align-items: center;
      gap: 8px;
      transition: background-color 0.3s, color 0.3s;
    }
    button.param-button:hover {
      background-color: var(--button-hover);
    }
    .measurement-item {
      background-color: #2a3660;
      border-radius: 10px;
      padding: 12px 14px;
      font-size: 13px;
      font-weight: 600;
      color: var(--text-light);
      margin-bottom: 8px;
      user-select: none;
    }
    [data-theme="light"] .measurement-item {
      background-color: #f2f6fc;
      color: var(--blue);
    }
    .measurement-main {
      display: flex;
      justify-content: space-between;
      user-select: none;
    }
    .measurement-sub {
      font-size: 11px;
      font-weight: 400;
      color: #7c8db7;
      margin-top: 4px;
      user-select: none;
    }
    .measurement-value {
      background-color: #b3c7f6;
      color: var(--text-heading);
      border-radius: 14px;
      padding: 3px 12px;
      font-weight: 700;
      font-size: 14px;
      min-width: 44px;
      text-align: center;
      user-select: none;
    }
    [data-theme="dark"] .measurement-value {
      background-color: #4a62ad;
      color: #fff;
    }
    .summary-item {
      display: flex;
      justify-content: space-between;
      font-weight: 600;
      font-size: 13px;
      color: var(--text-light);
      user-select: none;
    }
    .summary-item span:first-child {
      opacity: 0.8;
    }
    .summary-status {
      background-color: var(--param-bg);
      border-radius: 16px;
      color: var(--param-green);
      font-weight: 700;
      font-size: 13px;
      padding: 3px 12px;
      min-width: 100px;
      text-align: center;
      user-select: none;
    }
    .image-editing-bottom-bar {
      position: fixed;
      bottom: 0;
      left: 50%;
      transform: translateX(-50%);
      background-color: var(--panel-bg);
      border-radius: 12px 12px 0 0;
      padding: 10px 20px;
      display: flex;
      gap: 16px;
      user-select: none;
      z-index: 100;
      max-width: 95vw;
      box-shadow: 0 0 12px var(--panel-bg);
      flex-wrap: nowrap;
      overflow-x: auto;
      -webkit-overflow-scrolling: touch;
    }
    button.image-edit-btn {
      border: none;
      background: transparent;
      color: var(--text-light);
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      padding: 6px 12px;
      border-radius: 8px;
      user-select: none;
      display: flex;
      align-items: center;
      gap: 8px;
      white-space: nowrap;
      transition: background-color 0.25s, color 0.25s;
      flex-shrink: 0;
      flex-grow: 0;
    }
    button.image-edit-btn:hover {
      background-color: var(--accent);
      color: #fff;
    }
    button.image-edit-btn svg {
      stroke: var(--text-light);
      stroke-width: 2;
      width: 18px;
      height: 18px;
      user-select: none;
    }
    .topbar-right {
      display: flex;
      gap: 1rem;
      font-size: 14px;
      font-weight: 500;
      user-select: none;
      color: #fff;
    }
    [data-theme="light"] .topbar-right { color: var(--blue); }
    .icon-btn {
      border: none;
      background: transparent;
      color: inherit;
      cursor: pointer;
      display: flex;
      gap: 0.4rem;
      align-items: center;
      padding: 6px 10px;
      border-radius: 6px;
      font-weight: 600;
      transition: background-color 0.25s, color 0.25s;
      user-select: none;
      line-height: 1;
    }
    .icon-btn svg {
      stroke: currentColor;
      stroke-width: 2;
      width: 16px;
      height: 16px;
    }
    .icon-btn:hover {
      background-color: var(--accent);
      color: #fff;
    }
  `;

  // Theme icon toggle
  function ThemeToggleIcon() {
    return (
      <button
        className="theme-toggle-btn"
        title={darkMode ? "Switch to light mode" : "Switch to dark mode"}
        aria-label="Toggle dark/light mode"
        onClick={() => setDarkMode((d) => !d)}
      >
        {darkMode ? (
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <path d="M21 12.79A9 9 0 1 1 11.21 3a7 7 0 1 0 9.79 9.79z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        ) : (
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="5" stroke="currentColor" strokeWidth="2"/>
            <line x1="12" y1="1" x2="12" y2="3" stroke="currentColor" strokeWidth="2"/>
            <line x1="12" y1="21" x2="12" y2="23" stroke="currentColor" strokeWidth="2"/>
            <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" stroke="currentColor" strokeWidth="2"/>
            <line x1="18.36" y1="18.36" x2="19.78" y2="19.78" stroke="currentColor" strokeWidth="2"/>
            <line x1="1" y1="12" x2="3" y2="12" stroke="currentColor" strokeWidth="2"/>
            <line x1="21" y1="12" x2="23" y2="12" stroke="currentColor" strokeWidth="2"/>
            <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" stroke="currentColor" strokeWidth="2"/>
            <line x1="18.36" y1="5.64" x2="19.78" y2="4.22" stroke="currentColor" strokeWidth="2"/>
          </svg>
        )}
        <span style={{marginLeft:6, fontSize:13, fontWeight:600}}>{darkMode ? "Dark" : "Light"}</span>
      </button>
    );
  }

  return (
    <>
      <style>{globalStyles}</style>
      <header className="topbar" role="banner" aria-label="Primary navigation">
        <img src={logo} alt="SpineSurge Logo" className="logo" />
        <nav className="nav-center" aria-label="Main sections navigation">
          {navItems.map(({ label, icon }, idx) => (
            <React.Fragment key={label}>
              <button
                className={idx === 0 ? "active" : ""}
                aria-current={idx === 0 ? "page" : undefined}
                aria-label={`${label} section`}
                type="button"
                tabIndex={0}
              >
                {icon}
                {label}
              </button>
              {label === "Surgical" && <ThemeToggleIcon />}
            </React.Fragment>
          ))}
        </nav>
        <div className="topbar-right" aria-label="Utility actions">
          <button className="icon-btn" aria-label="Import" type="button">
            <svg viewBox="0 0 24 24" fill="none"><path d="M12 3v12m0 0l-4-4m4 4l4-4M21 21H3" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/></svg>
            <span>Import</span>
          </button>
          <button className="icon-btn" aria-label="Export" type="button">
            <svg viewBox="0 0 24 24" fill="none"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/><polyline points="17 8 12 3 7 8" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/></svg>
            <span>Export</span>
          </button>
          <button className="icon-btn" aria-label="Save" type="button">
            <svg viewBox="0 0 24 24" fill="none"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/><polyline points="17 21 17 13 7 13 7 21" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/></svg>
            <span>Save</span>
          </button>
          <button className="icon-btn" aria-label="Help" type="button">
            <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/><path d="M9.09 9a3 3 0 1 1 5.82 1c0 1.5-2 2.25-2 2.25" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/><line x1="12" y1="17" x2="12.01" y2="17" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
          <button className="icon-btn" aria-label="Settings" type="button">
            <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h.09a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
          <button className="icon-btn" aria-label="Logout" type="button">
            <svg viewBox="0 0 24 24" fill="none"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/><polyline points="16 17 21 12 16 7" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
        </div>
      </header>
      <div className="container" role="main" aria-label="Spinal analysis application">
        <aside className="sidebar" aria-label="Sidebar with tools and quick access">
          <div 
            className="collapse-control"
            onClick={()=>{
              setShowQuickAccess(!showQuickAccess);
              setShowToolCats(!showToolCats);
              setShowFavorites(!showFavorites);
            }}
            tabIndex={0}
            role="button"
            aria-pressed={showQuickAccess && showToolCats && showFavorites}
            aria-label="Collapse or expand sidebar sections"
            onKeyDown={(e) => {if(e.key==='Enter' || e.key===' ') {
              setShowQuickAccess(!showQuickAccess);
              setShowToolCats(!showToolCats);
              setShowFavorites(!showFavorites);
            }}}
          >
            &lt; Collapse
          </div>
          <section className={`sidebar-section ${showQuickAccess ? 'expanded' : 'collapsed'}`} aria-expanded={showQuickAccess}>
            <div className="section-header" onClick={() => setShowQuickAccess(!showQuickAccess)} tabIndex={0} role="button" onKeyDown={e => {
              if(e.key==='Enter' || e.key===' ') setShowQuickAccess(!showQuickAccess);
            }}>
              Quick Access
              <span>{showQuickAccess ? '▲' : '▼'}</span>
            </div>
            {showQuickAccess && (
              <div className="section-content" role="list">
                {quickAccessItems.map(({ icon, label }) => (
                  <button key={label} aria-label={label} role="listitem" title={label} className={`icon-${label.toLowerCase().replace(/\s+/g,'-')}`}>
                    <span style={{marginRight:'8px'}} aria-hidden="true">{icon}</span>
                    {label}
                  </button>
                ))}
              </div>
            )}
          </section>
          <section className={`sidebar-section ${showToolCats ? 'expanded' : 'collapsed'}`} aria-expanded={showToolCats}>
            <div className="section-header" onClick={() => setShowToolCats(!showToolCats)} tabIndex={0} role="button" onKeyDown={e => {
              if(e.key==='Enter' || e.key===' ') setShowToolCats(!showToolCats);
          
            }}>
              Favorites
              <span>{showFavorites ? '▲' : '▼'}</span>
            </div>
            {showFavorites && (
              <div className="section-content" role="list">
                {favorites.map(fav => (
                  <button key={fav} aria-label={fav} role="listitem" className="favorites" title={fav}>
                    <span style={{color:"var(--star)", marginRight: '5px'}}>⭐</span>{fav}
                  </button>
                ))}
              </div>
            )}
          </section>
        </aside>
        <main className="main-workspace" aria-label="Main analysis workspace">
          <div className="workspace-header">Analysis Workspace</div>
          <div className="upload-area" aria-label="Upload area for X-ray image">
            <div className="upload-icon" aria-hidden="true">⬆️</div>
            <div className="upload-text">Upload X-ray Image</div>
            <div className="upload-desc">Drop your X-ray image here or click to browse. Supports JPEG, PNG, and DICOM formats.</div>
            <button className="upload-button" type="button" aria-label="Select X-ray image">
              ⬆️ Select X-ray Image
            </button>
            <div className="zoom-controls" aria-label="Zoom and reset controls">
              <button className="zoom-btn" title="Zoom In" aria-label="Zoom In" type="button">🔍+</button>
              <button className="zoom-btn" title="Zoom Out" aria-label="Zoom Out" type="button">🔍−</button>
              <div className="zoom-divider" aria-hidden="true" />
              <button className="zoom-btn" title="Reset Rotation" aria-label="Reset Rotation" type="button">↻</button>
            </div>
          </div>
        </main>
        <aside className="right-panel" aria-label="Analysis results and summary">
          <section className="panel-section" aria-expanded={showSpinalParams} aria-label="Spinal Parameters">
            <h3
              onClick={() => setShowSpinalParams(!showSpinalParams)}
              tabIndex={0}
              role="button"
              onKeyDown={(e) => {if(e.key==='Enter'||e.key===' ') setShowSpinalParams(!showSpinalParams);}}
            >
              Spinal Parameters
              <span>{showSpinalParams ? '▲' : '▼'}</span>
            </h3>
            {showSpinalParams && <>
              {analysisResults.spinalParameters.map(({label,value,normal})=>(
                <div key={label} aria-label={`${label} value`}>
                  <div className="param-item">
                    <span>{label}</span>
                    <span className="param-value">{value}</span>
                  </div>
                  <div className="param-normal">{normal}</div>
                </div>
              ))}
              <button className="param-button" type="button" aria-label="Calculate Parameters">📋 Calculate Parameters</button>
            </>}
          </section>
          <section className="panel-section" aria-expanded={showMeasurements} aria-label="Measurements">
            <h3
              onClick={() => setShowMeasurements(!showMeasurements)}
              tabIndex={0}
              role="button"
              onKeyDown={(e) => {if(e.key==='Enter'||e.key===' ') setShowMeasurements(!showMeasurements);}}
            >
              Measurements
              <span>{showMeasurements ? '▲' : '▼'}</span>
            </h3>
            {showMeasurements && <>
              {analysisResults.measurements.map(({label,sub,value}) => (
                <div key={label} className="measurement-item" aria-label={`${label} measurement`}>
                  <div className="measurement-main">
                    <span>{label}</span>
                    <span className="measurement-value">{value}</span>
                  </div>
                  <div className="measurement-sub">{sub}</div>
                </div>
              ))}
            </>}
          </section>
          <section className="panel-section" aria-expanded={showSummary} aria-label="Analysis Summary">
            <h3
              onClick={() => setShowSummary(!showSummary)}
              tabIndex={0}
              role="button"
              onKeyDown={(e) => {if(e.key==='Enter'||e.key===' ') setShowSummary(!showSummary);}}
            >
              Analysis Summary
              <span>{showSummary ? '▲' : '▼'}</span>
            </h3>
            {showSummary && <>
              <div className="summary-item"><span>Total Measurements:</span><span>{analysisResults.summary.totalMeasurements}</span></div>
              <div className="summary-item"><span>Parameters Calculated:</span><span>{analysisResults.summary.parametersCalculated}</span></div>
              <div className="summary-item"><span>Status:</span><span className="summary-status">{analysisResults.summary.status}</span></div>
            </>}
          </section>
        </aside>
      </div>
      <div className="image-editing-bottom-bar" aria-label="Image editing tools toolbar">
        <button className="image-edit-btn" title="Brightness +" aria-label="Increase Brightness">
          <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="5" stroke="currentColor"/><line x1="12" y1="1" x2="12" y2="4" stroke="currentColor"/><line x1="12" y1="20" x2="12" y2="23" stroke="currentColor"/><line x1="4.22" y1="4.22" x2="6.34" y2="6.34" stroke="currentColor"/><line x1="17.66" y1="17.66" x2="19.78" y2="19.78" stroke="currentColor"/><line x1="1" y1="12" x2="4" y2="12" stroke="currentColor"/><line x1="20" y1="12" x2="23" y2="12" stroke="currentColor"/><line x1="4.22" y1="19.78" x2="6.34" y2="17.66" stroke="currentColor"/><line x1="17.66" y1="6.34" x2="19.78" y2="4.22" stroke="currentColor"/></svg>
          Brightness +
        </button>
        <button className="image-edit-btn" title="Brightness -" aria-label="Decrease Brightness">
          <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="5" stroke="currentColor"/><line x1="9" y1="12" x2="15" y2="12" stroke="currentColor"/></svg>
          Brightness -
        </button>
        <button className="image-edit-btn" title="Contrast +" aria-label="Increase Contrast">
          <svg viewBox="0 0 24 24" fill="none"><path d="M12 3a9 9 0 0 0 0 18" stroke="currentColor"/><path d="M12 3a9 9 0 1 1 0 18" stroke="currentColor"/></svg>
          Contrast +
        </button>
        <button className="image-edit-btn" title="Contrast -" aria-label="Decrease Contrast">
          <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="currentColor"/></svg>
          Contrast -
        </button>
        <button className="image-edit-btn" title="Toggle Max Brightness" aria-pressed={maxBrightness} aria-label="Toggle Max Brightness" onClick={() => setMaxBrightness(!maxBrightness)}>
          {maxBrightness ? (
            <>
              <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="currentColor"/><path d="M12 2v20" stroke="currentColor"/><path d="M2 12h20" stroke="currentColor"/></svg>
              Max Bright On
            </>
          ) : (
            <>
              <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="10" stroke="currentColor"/></svg>
              Max Bright Off
            </>
          )}
        </button>
        <button className="image-edit-btn" title="Rotate Left" aria-label="Rotate Left">
          <svg viewBox="0 0 24 24" fill="none"><path d="M4 7V4h3" stroke="currentColor"/><path d="M20 17a8 8 0 1 0-8-8" stroke="currentColor"/><polyline points="1 8 4 4 8 8" stroke="currentColor"/></svg>
          Rotate Left
        </button>
        <button className="image-edit-btn" title="Rotate Right" aria-label="Rotate Right">
          <svg viewBox="0 0 24 24" fill="none"><path d="M20 7v3h-3" stroke="currentColor"/><path d="M4 17a8 8 0 1 1 8-8" stroke="currentColor"/><polyline points="23 8 20 4 16 8" stroke="currentColor"/></svg>
          Rotate Right
        </button>
      </div>
    </>
  );
}
